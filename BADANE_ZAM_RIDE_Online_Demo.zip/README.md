# BADANE ZAM RIDE — Online Demo

This is a browser-based demonstration prototype for the BADANE ZAM RIDE customer, driver and administrator portals.

## Run locally
1. Install Node.js (LTS).
2. Open a terminal in this project folder.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL shown by Vite.

## Deploy to Vercel
1. Create/sign in to a GitHub account.
2. Create a new repository and upload the contents of this folder.
3. Sign in to Vercel using GitHub and import the repository.
4. Keep the default settings: Framework Preset `Vite`, Build Command `npm run build`, Output Directory `dist`.
5. Select Deploy. Vercel will provide a public demo URL.

## Important limitations
- This is a front-end demo with sample figures. It is not a production ride-hailing service.
- Demo changes are saved only in the current browser using localStorage.
- It has no real user authentication, shared database, live driver GPS, map routing, mobile-money integration, payment processing or push notifications.
- Do not use real customer or driver personal data.
- Before public launch, add a secure backend, database, role-based access control, payment reconciliation, audit logs, privacy and security controls, and required Zambian regulatory checks.
